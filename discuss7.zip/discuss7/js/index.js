// *** GLOBALS *** //
const canvas = document.getElementById('webgl-canvas');
const gl = canvas.getContext('webgl') || canvas.getContext('experimental-webgl');

var program;
const shapeData = [];

// *** SHADERS *** //
var vertexShaderSource = [
  'precision mediump float;',
  '',
  'attribute vec2 position;',
  'attribute vec3 color;',
  '',
  'varying vec3 fragColor;',
  '',
  'uniform mat4 matrix;',
  '',
  'void main() {',
  '  fragColor = color;',
  '  gl_Position = matrix * vec4(position, 0, 1);',
  '}'
].join('\n');

var fragmentShaderSource = [
  'precision mediump float;',
  '',
  'varying vec3 fragColor;',
  '',
  'void main() {',
  '  gl_FragColor = vec4(fragColor, 1);',
  '}'
].join('\n');

// *** FUNCTIONS ** //
function degToRad(degrees) {
  return degrees * (Math.PI / 180);
}

function clearScreen(r, g, b) {
  gl.clearColor(r, g, b, 1);
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
}

function initializeProgram() {
  const vertexShader = gl.createShader(gl.VERTEX_SHADER);
  gl.shaderSource(vertexShader, vertexShaderSource);
  gl.compileShader(vertexShader);
  console.log('Vertex Shader', gl.getShaderInfoLog(vertexShader));

  const fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
  gl.shaderSource(fragmentShader, fragmentShaderSource);
  gl.compileShader(fragmentShader);
  console.log('Fragment Shader', gl.getShaderInfoLog(fragmentShader));

  program = gl.createProgram();
  gl.attachShader(program, vertexShader);
  gl.attachShader(program, fragmentShader);
  gl.linkProgram(program);
  console.log(gl.getProgramInfoLog(program));

  gl.useProgram(program);
}

function initializeShape(position, color) {
  const positionBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, positionBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(position), gl.STATIC_DRAW);

  const colorBuffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, colorBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(color), gl.STATIC_DRAW);

  shapeData.push({
    transformMatrix: glMatrix.mat4.create(),
    position       : positionBuffer,
    color          : colorBuffer,
    count          : color.length / 3
  });

  return shapeData.length - 1;
}

function drawShape(index) {
  if (!program) {
    console.error('The program has not yet been initialized.');
    return;
  }

  if (index >= shapeData.length) {
    console.error('Index out of range.')
    return;
  }

  const data = shapeData[index];

  const positionLocation = gl.getAttribLocation(program, 'position');
  gl.enableVertexAttribArray(positionLocation);
  gl.bindBuffer(gl.ARRAY_BUFFER, data.position);
  gl.vertexAttribPointer(
    positionLocation, // Attribute
    2,                // Element Count
    gl.FLOAT,         // Type
    false,            // Normalization
    0,                // Stride
    0                 // Offset
  );

  const colorLocation = gl.getAttribLocation(program, 'color');
  gl.enableVertexAttribArray(colorLocation);
  gl.bindBuffer(gl.ARRAY_BUFFER, data.color);
  gl.vertexAttribPointer(
    colorLocation, // Attribute
    3,             // Element Count
    gl.FLOAT,      // Type
    false,         // Normalization
    0,             // Stride
    0              // Offset
  );

  const matrixUniformLocation = gl.getUniformLocation(program, 'matrix');
  gl.uniformMatrix4fv(matrixUniformLocation, false, data.transformMatrix);

  gl.drawArrays(gl.TRIANGLES, 0, shapeData[index].count);
}

function initialize() {
  initializeProgram();

  initializeShape([
    // First Half of Square
    -0.5,  0.5,
     0.5,  0.5,
    -0.5, -0.5,

    // Second Half of Square
     0.5, -0.5,
     0.5,  0.5,
    -0.5, -0.5
  ], [
    1, 0, 1,
    1, 1, 0,
    1, 1, 0,

    1, 0, 1,
    1, 1, 0,
    1, 1, 0,
  ]);


  animate();
}

var rotationZ = 0;
var scaleXY = 0;
var increment = 0.01;

function animate() {
  requestAnimationFrame(animate);

  clearScreen(0.3, 0.3, 0.7);

  shapeData[0].transformMatrix = glMatrix.mat4.create();
  glMatrix.mat4.scale(shapeData[0].transformMatrix, shapeData[0].transformMatrix, [scaleXY, scaleXY, 0]);
  glMatrix.mat4.rotateZ(shapeData[0].transformMatrix, shapeData[0].transformMatrix, degToRad(rotationZ));

  rotationZ += 1;
  scaleXY += increment;
  if (scaleXY <= -1 || scaleXY >= 1) {
    increment = -increment;
  }

  drawShape(0);
}
