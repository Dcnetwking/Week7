Author
======

This the work of Emil Persson, aka Humus.
http://www.humus.name

Downloaded from http://www.humus.name/index.php?page=Textures
by David Eck, and converted to a smaller 512x512 size for use
with WebGL in his free, on-line textbook at 
http://math.hws.edu/graphicsbook



License
=======

This work is licensed under a Creative Commons Attribution 3.0 Unported License.
http://creativecommons.org/licenses/by/3.0/
